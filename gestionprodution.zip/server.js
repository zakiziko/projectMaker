const express =require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const db = require('./config/db');
const Produit = require('./routes/Produit');
const Fournisseur = require('./routes/Fournisseur');
const app = express();
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());
const port = 5000
mongoose.connect(db.databaseUri,db.options).then(
        ()=>{console.log('SUCCEFFULY CONNECTED TO MONGODB !!');},
        (err)=>{console.log(err);}
    );
app.listen(port,()=>{console.log('SERVER IS RUNNING ON :'+port)})
app.use('/api', Produit);
app.use('/api', Fournisseur);
