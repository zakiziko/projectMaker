
const mongoose = require('mongoose');
const schema = mongoose.Schema;
const ProduitSchema = new schema({ qualite:String,
 prix:Number,
 designation:String,
 Fournisseur:{type: mongoose.Schema.Types.ObjectId, ref: 'Fournisseur'},
});
module.exports = mongoose.model('Produit',ProduitSchema);