
const mongoose = require('mongoose');
const schema = mongoose.Schema;
const FournisseurSchema = new schema({ name:String,
 email:String,
 type:String,
 Produit:[{type: mongoose.Schema.Types.ObjectId, ref: 'Produit'}],
});
module.exports = mongoose.model('Fournisseur',FournisseurSchema);