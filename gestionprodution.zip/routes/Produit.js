
const express = require('express');
const route = express.Router();
const reducer = require('../config/reducer');
let Produit = require('../models/Produit');
route.get('/Produit',(req,res)=>{
    const atts =  Produit.schema.obj;
    const populateObj=[];
    for(t in atts){
       if(Object.prototype.toString.call(atts[t]).slice(8, -1)=='Object'){
        populateObj.push(t);
       }
    }
   Produit.find({}).populate(populateObj)
   .exec((err,response)=>{
        if(err) throw err;
        res.json(response);
    });
});
route.get('/Produit/:id',(req,res)=>{
    Produit.find({_id:req.params.id},(err,response)=>{
        if(err) throw err;
        res.json(response);
    });
});

route.post('/Produit',(req,res)=>{
    const atts = Produit.schema.obj;
    let model = {};
    for(t in atts){
       model[t]=req.body[t];
    }
    const newModel = new Produit(model);
    newModel.save(function(err,result){
        if(err){
            res.json({'err':err});
        }else{
            const refs = Produit.schema.obj;
            for(t in refs){
                if(Object.prototype.toString.call(refs[t]).slice(8, -1)=='Object'){
                    reducer.update('Produit',result._id,t,result[t]);
                }
            }
            res.json(result);
        }
    });
});

module.exports = route;