const Produit = require('../models/Produit');
const Fournisseur = require('../models/Fournisseur');


function getModel(model){
    switch (model) {
       
    case 'Produit':
    return Produit;
    break;

    case 'Fournisseur':
    return Fournisseur;
    break;

        default:
        break;
    }
}

function update(curentModel,curentModelId,distModel,distModelId){
    const crModel = getModel(curentModel);
    const dsModel = getModel(distModel);
    const atts = dsModel.schema.obj;
    for(t in atts){
        if(t==curentModel){
            const obj ={};
            obj[curentModel] = curentModelId;
            dsModel.findByIdAndUpdate(distModelId,{'$push': obj }).exec((err,auth)=>{
                console.log(auth);
            });
        }
    }

   
}
module.exports = {
    update
}

