const Book = require('../models/Book');
const Author = require('../models/Author');


function getModel(model){
    switch (model) {
       
    case 'Book':
    return Book;
    break;

    case 'Author':
    return Author;
    break;

        default:
        break;
    }
}

function update(curentModel,curentModelId,distModel,distModelId){
    const crModel = getModel(curentModel);
    const dsModel = getModel(distModel);
    const atts = dsModel.schema.obj;
    for(t in atts){
        if(t==curentModel){
            const obj ={};
            obj[curentModel] = curentModelId;
            dsModel.findByIdAndUpdate(distModelId,{'$push': obj }).exec((err,auth)=>{
                console.log(auth);
            });
        }
    }

   
}
module.exports = {
    update
}

