
const mongoose = require('mongoose');
const schema = mongoose.Schema;
const AuthorSchema = new schema({ name:String,
 email:String,
 description:String,
 Book:[{type: mongoose.Schema.Types.ObjectId, ref: 'Book'}],
});
module.exports = mongoose.model('Author',AuthorSchema);