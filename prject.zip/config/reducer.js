const Fournisseur = require('../models/Fournisseur');
const BonLivraison = require('../models/BonLivraison');
const Produit = require('../models/Produit');


function getModel(model){
    switch (model) {
       
    case 'Fournisseur':
    return Fournisseur;
    break;

    case 'BonLivraison':
    return BonLivraison;
    break;

    case 'Produit':
    return Produit;
    break;

        default:
        break;
    }
}

function update(curentModel,curentModelId,distModel,distModelId){
    const crModel = getModel(curentModel);
    const dsModel = getModel(distModel);
    const atts = dsModel.schema.obj;
    for(t in atts){
        if(t==curentModel){
            const obj ={};
            obj[curentModel] = curentModelId;
            dsModel.findByIdAndUpdate(distModelId,{'$push': obj }).exec((err,auth)=>{
                console.log(auth);
            });
        }
    }

   
}
module.exports = {
    update
}

