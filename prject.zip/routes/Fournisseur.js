
const express = require('express');
const route = express.Router();
const reducer = require('../config/reducer');
let Fournisseur = require('../models/Fournisseur');
route.get('/Fournisseur',(req,res)=>{
    const atts =  Fournisseur.schema.obj;
    const populateObj=[];
    for(t in atts){
       if(Object.prototype.toString.call(atts[t]).slice(8, -1)=='Object'){
        populateObj.push(t);
       }
    }
   Fournisseur.find({}).populate(populateObj)
   .exec((err,response)=>{
        if(err) throw err;
        res.json(response);
    });
});
route.get('/Fournisseur/:id',(req,res)=>{
    Fournisseur.find({_id:req.params.id},(err,response)=>{
        if(err) throw err;
        res.json(response);
    });
});

route.post('/Fournisseur',(req,res)=>{
    const atts = Fournisseur.schema.obj;
    let model = {};
    for(t in atts){
       model[t]=req.body[t];
    }
    const newModel = new Fournisseur(model);
    newModel.save(function(err,result){
        if(err){
            res.json({'err':err});
        }else{
            const refs = Fournisseur.schema.obj;
            for(t in refs){
                if(Object.prototype.toString.call(refs[t]).slice(8, -1)=='Object'){
                    reducer.update('Fournisseur',result._id,t,result[t]);
                }
            }
            res.json(result);
        }
    });
});

module.exports = route;