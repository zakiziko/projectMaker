
const express = require('express');
const route = express.Router();
const reducer = require('../config/reducer');
let BonLivraison = require('../models/BonLivraison');
route.get('/BonLivraison',(req,res)=>{
    const atts =  BonLivraison.schema.obj;
    const populateObj=[];
    for(t in atts){
       if(Object.prototype.toString.call(atts[t]).slice(8, -1)=='Object'){
        populateObj.push(t);
       }
    }
   BonLivraison.find({}).populate(populateObj)
   .exec((err,response)=>{
        if(err) throw err;
        res.json(response);
    });
});
route.get('/BonLivraison/:id',(req,res)=>{
    BonLivraison.find({_id:req.params.id},(err,response)=>{
        if(err) throw err;
        res.json(response);
    });
});

route.post('/BonLivraison',(req,res)=>{
    const atts = BonLivraison.schema.obj;
    let model = {};
    for(t in atts){
       model[t]=req.body[t];
    }
    const newModel = new BonLivraison(model);
    newModel.save(function(err,result){
        if(err){
            res.json({'err':err});
        }else{
            const refs = BonLivraison.schema.obj;
            for(t in refs){
                if(Object.prototype.toString.call(refs[t]).slice(8, -1)=='Object'){
                    reducer.update('BonLivraison',result._id,t,result[t]);
                }
            }
            res.json(result);
        }
    });
});

module.exports = route;