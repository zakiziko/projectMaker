
const mongoose = require('mongoose');
const schema = mongoose.Schema;
const ProduitSchema = new schema({ qualite:String,
 prix:Number,
 designation:String,
 BonLivraison:{type: mongoose.Schema.Types.ObjectId, ref: 'BonLivraison'},
});
module.exports = mongoose.model('Produit',ProduitSchema);