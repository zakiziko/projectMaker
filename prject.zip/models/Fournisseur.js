
const mongoose = require('mongoose');
const schema = mongoose.Schema;
const FournisseurSchema = new schema({ name:String,
 email:String,
 description:String,
 BonLivraison:[{type: mongoose.Schema.Types.ObjectId, ref: 'BonLivraison'}],
});
module.exports = mongoose.model('Fournisseur',FournisseurSchema);