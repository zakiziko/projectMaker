
const mongoose = require('mongoose');
const schema = mongoose.Schema;
const BonLivraisonSchema = new schema({ dateLivraison:Date,
 Fournisseur:{type: mongoose.Schema.Types.ObjectId, ref: 'Fournisseur'},
});
module.exports = mongoose.model('BonLivraison',BonLivraisonSchema);