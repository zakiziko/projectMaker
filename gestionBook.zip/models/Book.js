
const mongoose = require('mongoose');
const schema = mongoose.Schema;
const BookSchema = new schema({ name:String,
 prix:Number,
 Author:{type: mongoose.Schema.Types.ObjectId, ref: 'Author'},
});
module.exports = mongoose.model('Book',BookSchema);